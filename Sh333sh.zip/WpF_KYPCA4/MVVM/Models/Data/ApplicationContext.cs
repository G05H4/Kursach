﻿using Microsoft.EntityFrameworkCore;

namespace WpF_KYPCA4.MVVM.Models.Data
{
    public class ApplicationContext : DbContext
    {
        public DbSet<Cabinet> Cabinets { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Register> Registers { get; set; }
        public DbSet<Group> Groups { get; set; }

        public ApplicationContext() => Database.EnsureCreated();

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //optionsBuilder.UseSqlServer("Data Source=DESKTOP-I8L1GP6;Initial Catalog=Cabinets;Integrated Security = True");
            //optionsBuilder.UseSqlServer(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=Cabinets;User ID=sa; Password=4321193");
            optionsBuilder.UseSqlServer(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=Cabinets;Integrated Security = True");

        }
    }
}
