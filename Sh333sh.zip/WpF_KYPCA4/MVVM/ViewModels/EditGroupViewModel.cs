﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpF_KYPCA4.Commands;
using WpF_KYPCA4.MVVM.Models;

namespace WpF_KYPCA4.MVVM.ViewModels
{
    public class EditGroupViewModel : Command
    {
        public RelayCommand EditGroup
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    Window wnd = obj as Window;
                    string resultStr = "";
                    if (SelectedGroup == null)
                    {
                        ShowMessageToUser("Не выбрана группа");
                    }
                    else if (CabinetName == null)
                    {
                        ShowMessageToUser("Не выбрано название");
                    }
                    else
                    {
                        resultStr = DBWorker.EditGroup(SelectedGroup,GroupName);
                        UpdateInfoView();
                        ShowMessageToUser(resultStr);
                        SetNullValuesToProperties();
                        wnd.Close();
                    }
                }
                );
            }
        }
    }
}
