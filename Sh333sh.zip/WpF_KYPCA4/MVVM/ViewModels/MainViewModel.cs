﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpF_KYPCA4.Commands;
using WpF_KYPCA4.MVVM.Models;
using WpF_KYPCA4.MVVM.Views;

namespace WpF_KYPCA4.MVVM.ViewModels
{
    public class MainViewModel : Command
    {
        public RelayCommand OpenAddWindow
        {
            get 
            {
                return new RelayCommand(obj =>
                {
                    if (SelectedTabItem.Name == "Cabinets")
                    {
                        OpenAddCabinetWindow();
                    }
                    else if (SelectedTabItem.Name == "Groups")
                    {
                        OpenAddGroupWindow();
                    }
                    else if (SelectedTabItem.Name == "Teachers")
                    {
                        OpenAddTeacherWindow();
                    }
                });
            }
        }
        public RelayCommand OpenEditWindow
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    if (SelectedTabItem.Name == "Cabinets")
                    {
                        OpenEditCabinetWindow();
                    }
                    else if (SelectedTabItem.Name == "Groups")
                    {
                        OpenEditGroupWindow();
                    }
                    else if (SelectedTabItem.Name == "Teachers")
                    {
                        OpenEditTeacherWindow();
                    }
                });
            }
        }
        #region SwapStatus
        public RelayCommand OpenTakeWindow
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    if (SelectedCabinet==null)
                    {
                        ShowMessageToUser("Выберите кабинет");
                    }
                    else
                    {
                        OpenTakeCabinetWindow(SelectedCabinet.FullName);
                    }

                });
            }
        }
        public RelayCommand SwapStatus
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    string resultStr;

                    if (SelectedCabinet==null)
                    {
                        resultStr = "Выберите кабинет";
                    }
                    else
                    {
                        resultStr = DBWorker.NoTakeCabinet(SelectedCabinet);
                        UpdateInfoView();
                        ShowMessageToUser(resultStr);
                        SetNullValuesToProperties();
                    }

                });
            }
        }
        #endregion
        private void OpenTakeCabinetWindow(string cabinet)
        {
            TakeCabinetWindow takeCabinetWindow  = new TakeCabinetWindow(cabinet);
            SetCenterPositionAndOpen(takeCabinetWindow);
        }
        private void OpenAddCabinetWindow()
        {
            AddCabinetWindow addCabinetWindow = new AddCabinetWindow();
            SetCenterPositionAndOpen(addCabinetWindow);
        }
        private void OpenAddGroupWindow()
        {
            AddGroupWindow addGroupWindow = new AddGroupWindow();
            SetCenterPositionAndOpen(addGroupWindow);
        }
        private void OpenAddTeacherWindow()
        {
            AddTeacherWindow addTeacherWindow = new AddTeacherWindow();
            SetCenterPositionAndOpen(addTeacherWindow);
        }
        #region COMMANDS TO DELETE
        public RelayCommand DeleteCabinet
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    string resultStr = "";
                    if (SelectedCabinet == null)
                    {
                        ShowMessageToUser("Не выбран кабинет");
                    }
                    else
                    {
                        resultStr = DBWorker.DeleteCabinet(SelectedCabinet);
                        UpdateInfoView();

                        ShowMessageToUser(resultStr);
                        SetNullValuesToProperties();
                    }
                }
                );
            }
        }
        public RelayCommand DeleteGroup
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    string resultStr = "";
                    if (SelectedGroup == null)
                    {
                        ShowMessageToUser("Не выбрана группа");
                    }
                    else
                    {
                        resultStr = DBWorker.DeleteGroup(SelectedGroup);
                        UpdateInfoView();

                        ShowMessageToUser(resultStr);
                        SetNullValuesToProperties();
                    }
                }
                );
            }
        }
        public RelayCommand DeleteTeacher
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    string resultStr = "";
                    if (SelectedTeacher == null)
                    {
                        ShowMessageToUser("Не выбран учитель");
                    }
                    else
                    {
                        resultStr = DBWorker.DeleteTeacher(SelectedTeacher);
                        UpdateInfoView();

                        ShowMessageToUser(resultStr);
                        SetNullValuesToProperties();
                    }
                }
                );
            }
        }
        #endregion
        private void OpenEditCabinetWindow()
        {
            EditCabinetWindow editCabinetWindow = new EditCabinetWindow();
            SetCenterPositionAndOpen(editCabinetWindow);
        }
        private void OpenEditGroupWindow()
        {
            EditGroupWindow editGroupWindow = new EditGroupWindow();
            SetCenterPositionAndOpen(editGroupWindow);
        }
        private void OpenEditTeacherWindow()
        {
            EditTeacherWindow editTeacherWindow = new EditTeacherWindow();
            SetCenterPositionAndOpen(editTeacherWindow);
        }
    }
}
