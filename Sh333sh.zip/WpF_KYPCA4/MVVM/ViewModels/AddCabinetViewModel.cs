﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpF_KYPCA4.Commands;
using WpF_KYPCA4.MVVM.Models;

namespace WpF_KYPCA4.MVVM.ViewModels
{
    public class AddCabinetViewModel : Command
    {
        #region COMMANDS TO ADD
        public RelayCommand AddNewCabinet
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    Window wnd = obj as Window;
                    string resultStr = "";
                    if (CabinetName == null || CabinetName.Replace(" ", "").Length == 0)
                    {
                        Command.ShowMessageToUser("Некорректное название");
                    }
                    else if (CabinetNumber == 0)
                    {
                        Command.ShowMessageToUser("Некорректный номер");
                    }
                    else
                    {
                        resultStr = DBWorker.CreateCabinet(CabinetNumber,CabinetName);
                        UpdateInfoView();

                        ShowMessageToUser(resultStr);
                        SetNullValuesToProperties();
                        wnd.Close();
                    }
                }
                );
            }
        }
        #endregion
    }
}
