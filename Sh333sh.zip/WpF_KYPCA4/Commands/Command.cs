﻿using WpF_KYPCA4.MVVM.Models;
using WpF_KYPCA4.MVVM.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using WpF_KYPCA4.Commands;

namespace WpF_KYPCA4.MVVM.ViewModels
{
    public class Command : INotifyPropertyChanged
    {
        //все Студенты
        private List<Teacher> allTeachers = DBWorker.GetAllTeachers();
        public List<Teacher> AllTeachers
        {
            get { return allTeachers; }
            set
            {
                allTeachers = value;
                NotifyPropertyChanged("AllTeachers");
            }
        }
        ////все Кабинеты
        private List<Cabinet> allCabinets = DBWorker.GetAllCabinets();
        public List<Cabinet> AllCabinets
        {
            get { return allCabinets; }
            set
            {
                allCabinets = value;
                NotifyPropertyChanged("AllCabinets");
            }
        }
        //все Группы
        private List<Group> allGroups = DBWorker.GetAllGroups();
        public List<Group> AllGroups
        {
            get { return allGroups; }
            set
            {
                allGroups = value;
                NotifyPropertyChanged("AllGroups");
            }
        }


        //все Оценки по студенту
        //private List<BusyCabinet> allGradesByStudentId;
        //public List<BusyCabinet> AllGradesByStudentId
        //{
        //    get { return allGradesByStudentId; }
        //    set
        //    {
        //        allGradesByStudentId = value;
        //        NotifyPropertyChanged("AllGradesByStudentId");
        //    }
        //}
        ////все Студенты по группе
        //private List<Teacher> allStudentsByGroupId;
        //public List<Teacher> AllStudentsByGroupId
        //{
        //    get { return allStudentsByGroupId; }
        //    set
        //    {
        //        allStudentsByGroupId = value;
        //        NotifyPropertyChanged("AllStudentsByGroupId");
        //    }
        //}
        ////все Оценки по дисциплине
        //private List<BusyCabinet> allGradesByDisciplineId;
        //public List<BusyCabinet> AllGradesByDisciplineId
        //{
        //    get { return allGradesByDisciplineId; }
        //    set
        //    {
        //        allGradesByDisciplineId = value;
        //        NotifyPropertyChanged("AllGradesByDisciplineId");
        //    }
        //}
        ////все Оценки по группе
        //private List<BusyCabinet> allGradesByGroupId;
        //public List<BusyCabinet> AllGradesByGroupId
        //{
        //    get { return allGradesByGroupId; }
        //    set
        //    {
        //        allGradesByGroupId = value;
        //        NotifyPropertyChanged("AllGradesByGroupId");
        //    }
        //}
        ////все Оценки по студенту и дисциплине
        //private List<BusyCabinet> allGradesByStudentDisciplineId;
        //public List<BusyCabinet> AllGradesByStudentDisciplineId
        //{
        //    get { return allGradesByStudentDisciplineId; }
        //    set
        //    {
        //        allGradesByStudentDisciplineId = value;
        //        NotifyPropertyChanged("AllGradesByStudentDisciplineId");
        //    }
        //}


        //свойства для дисциплин
        public static Cabinet CabinetInf { get; set; }
        public static string CabinetName { get; set; }
        public static int CabinetNumber { get; set; }
        public static string CabinetStatus { get; set; }


        //свойства для пользователя
        public static string Login { get; set; }
        public static string Password { get; set; }
        //свойства для Студента
        public static Teacher TeacherInf { get; set; }
        public static string TeacherFirstName { get; set; }
        public static string TeacherLastName { get; set; }
        public static string TeacherMiddleName { get; set; }



        //свойства для выделенных элементов
        public Group GroupInf { get; set; }
        public static string GroupName { get; set; }


        //|ля
        public TabItem SelectedTabItem { get; set; }
        public static Teacher SelectedTeacher { get; set; }
        public static Cabinet SelectedCabinet { get; set; }
        public static Group SelectedGroup { get; set; }

        #region METHODS TO OPEN WINDOW

        protected void SetCenterPositionAndOpen(Window window)
        {
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
        }
        #endregion

        #region UPDATE VIEWS
        public static void SetNullValuesToProperties()
        {
            //для Студента
            TeacherFirstName = null;
            TeacherLastName = null;
            TeacherMiddleName = null;
            //для Оценки
            CabinetName = null;
            CabinetNumber = 0;
            TeacherFirstName = null;
            TeacherLastName = null;
            TeacherMiddleName = null;
            GroupName = null;
            CabinetStatus = null;

            //для Пользоваетля
            Login = null;
            Password = null;
        }
        protected void UpdateInfoView()
        {
            UpdateCabinetsMWInfo();
            UpdateGroupsMWInfo();
            UpdateTeachersMWInfo();
        }
        protected void UpdateCabinetsMWInfo()
        {
            MainWindow.LWCabinets.ItemsSource = null;
            MainWindow.LWCabinets.Items.Clear();
            MainWindow.LWCabinets.ItemsSource = DBWorker.GetAllCabinets();
            MainWindow.LWCabinets.Items.Refresh();
        }
        protected void UpdateGroupsMWInfo()
        {
            MainWindow.LWGroups.ItemsSource = null;
            MainWindow.LWGroups.Items.Clear();
            MainWindow.LWGroups.ItemsSource = DBWorker.GetAllGroups();
            MainWindow.LWGroups.Items.Refresh();
        }
        protected void UpdateTeachersMWInfo()
        {
            MainWindow.LWTeachers.ItemsSource = null;
            MainWindow.LWTeachers.Items.Clear();
            MainWindow.LWTeachers.ItemsSource = DBWorker.GetAllTeachers();
            MainWindow.LWTeachers.Items.Refresh();
        }
        #endregion
        public static void ShowMessageToUser(string message)
        {
            MessageBox.Show(message,"Информация",MessageBoxButton.OK,MessageBoxImage.Information);
            
        }
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
