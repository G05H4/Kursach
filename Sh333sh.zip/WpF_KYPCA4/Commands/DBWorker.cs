﻿using WpF_KYPCA4.MVVM.Models.Data;
using System.Collections.Generic;
using System.Linq;
using System;
using WpF_KYPCA4.MVVM.ViewModels;
using WpF_KYPCA4.MVVM.Models;

namespace WpF_KYPCA4.Commands
{
    public static class DBWorker
    {
        //получить всех студентов
        public static List<Teacher> GetAllTeachers()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                var result = db.Teachers.ToList();
                return result;
            }
        }
        
        //получить все Дисциплины
        public static List<Cabinet> GetAllCabinets()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                var result = db.Cabinets.ToList();
                return result;
            }
        }
        public static List<Group> GetAllGroups()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                var result = db.Groups.ToList();
                return result;
            }
        }
        //создать Студента
        public static string CreateTeacher(string firstName, string lastName, string middleName)
        {
            string result = "Уже существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //проверяем сущесвует ли студент
                bool checkIsExist = db.Teachers.Any(el => el.FirstName == firstName && el.LastName == lastName && el.MiddleName == middleName);
                if (!checkIsExist)
                {
                    Teacher newTeacher = new Teacher
                    {
                        FirstName = firstName,
                        LastName = lastName,
                        MiddleName = middleName
                    };
                    db.Teachers.Add(newTeacher);
                    db.SaveChanges();
                    result = "Учитель добавлен!";
                }
                return result;
            }
        }
        //создать Группу
        public static string CreateGroup(string name)
        {
            string result = "Уже существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //проверяем сущесвует ли группа
                bool checkIsExist = db.Groups.Any(el => el.Name == name);
                if (!checkIsExist)
                {
                    Group newGroup = new Group
                    {
                        Name = name
                    };
                    db.Groups.Add(newGroup);
                    db.SaveChanges();
                    result = "Группа добавлена!";
                }
                return result;
            }
        }
        
        //создать Дисчиплину
        public static string CreateCabinet(int cabinetNumber, string cabinetName)
        {
            string result = "Уже существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //check the user is exist
                bool checkIsExist = db.Cabinets.Any(el => el.CabinetName == cabinetName && el.CabinetNumber == cabinetNumber);
                if (!checkIsExist)
                {
                    Cabinet newCabinet = new Cabinet
                    {
                        CabinetName = cabinetName,
                        CabinetNumber = cabinetNumber
                    };
                    db.Cabinets.Add(newCabinet);
                    db.SaveChanges();
                    result = "Сделано!";
                }
                return result;
            }
        }
        //создать пользователя
        public static bool CheckAuthUser(string login, string password)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                return db.Registers.Any(el => el.Password == password && el.Login == login);
            }
        }
        public static string CreateUser(string login, string password)
        {
            string result = "Уже существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //check the user is exist
                bool checkIsExist = db.Registers.Any(el => el.Password == password && el.Login == login);
                if (!checkIsExist)
                {
                    Register newUser = new Register
                    {
                        Login = login,
                        Password = password,
                    };
                    db.Registers.Add(newUser);
                    db.SaveChanges();
                    result = "Пользователь добавлен!";
                }
                return result;
            }
        }
        //удаление Оценку
        public static string DeleteCabinet(Cabinet cabinet)
        {
            string result = "Такого кабинета не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                db.Cabinets.Remove(cabinet);
                db.SaveChanges();
                result = $"Сделано! Кабинет {cabinet.CabinetName} - {cabinet.CabinetNumber} удалён!";
            }
            return result;
        }
        
        //удаление Дисциплины
        public static string DeleteTeacher(Teacher teacher)
        {
            string result = "Такой учителя не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //check position is exist
                db.Teachers.Remove(teacher);
                db.SaveChanges();
                result = $"Сделано! Учитель {teacher.FullName} удалён!";
            }
            return result;
        }
        //удаление Группы
        public static string DeleteGroup(Group group)
        {
            string result = "Такой группы не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //check position is exist
                db.Groups.Remove(group);
                db.SaveChanges();
                result = $"Сделано! Группа {group.Name} удалена!";
            }
            return result;
        }

        //редактирование статуса кабинета
        public static string TakeCabinet(Cabinet oldCabinet,Teacher teacher, Group group)
        {
            string result = "Ошибка";
            using (ApplicationContext db = new ApplicationContext())
            {
                Cabinet cabinet = db.Cabinets.FirstOrDefault(cabinet => cabinet.Id == oldCabinet.Id);
                cabinet.CabinetStatus = $"Занят: {teacher.FullName} - {group.Name}";
                db.SaveChanges();
                result = $"Сделано! Статус кабинета {cabinet.FullName} изменен!";
            }
            return result;
        }

        public static string NoTakeCabinet(Cabinet oldCabinet)
        {
            string result = "Ошибка";
            using (ApplicationContext db = new ApplicationContext())
            {
                Cabinet cabinet = db.Cabinets.FirstOrDefault(cabinet => cabinet.Id == oldCabinet.Id);
                cabinet.CabinetStatus = $"Не занят";
                db.SaveChanges();
                result = $"Сделано! Статус кабинета {cabinet.FullName} изменен!";
            }
            return result;
        }
        //редактирование Группы
        public static string EditGroup(Group oldGroup, string newName)
        {
            string result = "Такой группы не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                Group group = db.Groups.FirstOrDefault(group => group.Id == oldGroup.Id);
                group.Name = newName;
                db.SaveChanges();
                result = $"Сделано! Группа {group.Name} изменена!";
            }
            return result;
        }

        //редактирование Студента
        public static string EditTeacher(Teacher oldTeacher, string newFirstName, string newLastName, string newMiddleName)
        {
            string result = "Такого учителя не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                Teacher teacher = db.Teachers.FirstOrDefault(teacher => teacher.Id == oldTeacher.Id);
                teacher.FirstName = newFirstName;
                teacher.LastName = newLastName;
                teacher.MiddleName = newMiddleName;//123
                db.SaveChanges();
                result = $"Сделано! Учитель {teacher.FullName} изменен!";
            }
            return result;
        }
        //редактирование Дисиплины
        public static string EditCabinet(Cabinet oldCabinet, int newCabinetNumber, string newCabinetName)
        {
            string result = "Такого кабинета не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                Cabinet cabinet = db.Cabinets.FirstOrDefault(cabinet => cabinet.Id == oldCabinet.Id );
                cabinet.CabinetName = newCabinetName;
                cabinet.CabinetNumber = newCabinetNumber;
                db.SaveChanges();
                result = $"Сделано! Кабинет {cabinet.CabinetName} изменён!";
            }
            return result;
        }
        
        //получение студента по id студента
        public static Teacher GetTeacherById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                Teacher teacher = db.Teachers.FirstOrDefault(teacher => teacher.Id == id);
                return teacher;
            }
        }
        //получение дисциплины по id дисциплины
        public static Cabinet GetCabinetById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                Cabinet cabinet = db.Cabinets.FirstOrDefault(cabinet => cabinet.Id == id);
                return cabinet;
            }
        }
        
        //получение группы по id группы
        public static Group GetGroupById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                Group group = db.Groups.FirstOrDefault(group => group.Id == id);
                return group;
            }
        }
        //получение всех студентов по id группы
        //public static List<Teacher> GetAllStudentsByGroupId(int id)
        //{
        //    using (ApplicationContext db = new ApplicationContext())
        //    {
        //        List<Teacher> students = (from student in GetAllStudents() where student.GroupId == id select student).ToList();
        //        return students;
        //    }
        //}
        ////получение всех оценок по id дисциплины
        //public static List<BusyCabinet> GetAllGradesByDisciplineId(int id)
        //{
        //    using (ApplicationContext db = new ApplicationContext())
        //    {
        //        List<BusyCabinet> grades = (from grade in GetAllGrades() where grade.DisciplineId == id select grade).ToList();
        //        return grades;
        //    }
        //}
        ////получение всех оценок по id студента
        //public static List<BusyCabinet> GetAllGradesByGroupId(int id)
        //{
        //    using (ApplicationContext db = new ApplicationContext())
        //    {
        //        List<BusyCabinet> grades = (from grade in GetAllGrades() where grade.GradeStudent.GroupId == id select grade).ToList();
        //        return grades;
        //    }
        //}
        ////получение всех оценок по id студента и дсициплины
        //public static List<BusyCabinet> GetAllGradesByStudentDisciplineId(int studentId, int disciplineId)
        //{
        //    using (ApplicationContext db = new ApplicationContext())
        //    {
        //        List<BusyCabinet> grades = (from grade in GetAllGrades() where grade.StudentId == studentId && grade.DisciplineId == disciplineId select grade).ToList();
        //        return grades;
        //    }
        //}
        ////получение всех оценок по id студента
        //public static List<BusyCabinet> GetAllGradesByStudentId(int id)
        //{
        //    using (ApplicationContext db = new ApplicationContext())
        //    {
        //        List<BusyCabinet> grades = (from grade in GetAllGrades() where grade.StudentId == id select grade).ToList();
        //        return grades;
        //    }
        //}
        ////получение всех оценок по id студента
        //public static List<BusyCabinet> GetAllGradesByStudentAndDisciplineId(int id)
        //{
        //    using (ApplicationContext db = new ApplicationContext())
        //    {
        //        List<BusyCabinet> grades = (from grade in GetAllGrades() where grade.StudentId == id && grade.DisciplineId == id select grade).ToList();
        //        return grades;
        //    }
        //}
        #region USEFUL METHODS
        ////получение студента по id оценки
        //public static string GetTeacherByCabinetId(int cabinetId)
        //{
        //    using (ApplicationContext db = new ApplicationContext())
        //    {
        //        Teacher teacher = db.Teachers.FirstOrDefault(teacher => teacher.Id == cabinetId);
        //        return teacher.FullName;
        //    }
        //}
        ////получение группы по id студента
        //public static string GetGroupByStudentId(int studentGroupId)
        //{
        //    using (ApplicationContext db = new ApplicationContext())
        //    {
        //        Group group = db.Groups.FirstOrDefault(group => group.Id == studentGroupId);
        //        return group.GroupName;
        //    }
        //}
        #endregion
    }
}
