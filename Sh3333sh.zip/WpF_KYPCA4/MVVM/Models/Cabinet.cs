﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpF_KYPCA4.Commands;

namespace WpF_KYPCA4.MVVM.Models
{
    public class Cabinet
    {
        public int Id { get; set; }
        public int CabinetNumber { get; set; }
        public string CabinetName { get; set; } = null!;
        public string CabinetStatus { get; set;} = "Не занят";
        [NotMapped]
        public string FullName => $"{CabinetName} - {CabinetNumber}";       
    }
}
