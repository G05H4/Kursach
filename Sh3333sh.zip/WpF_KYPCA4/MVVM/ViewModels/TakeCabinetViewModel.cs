﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpF_KYPCA4.Commands;
using WpF_KYPCA4.MVVM.Models;

namespace WpF_KYPCA4.MVVM.ViewModels
{
    internal class TakeCabinetViewModel:Command
    {
        #region COMMANDS TO TAKE
        public RelayCommand TakeThisCabinet
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    Window wnd = obj as Window;
                    string resultStr = "";
                    if (SelectedTeacher == null)
                    {
                        ShowMessageToUser("Не выбран преподаватель");
                    }
                    else if(SelectedGroup==null)
                    {
                        ShowMessageToUser("Не выбрана группа");
                    }
                    else
                    {
                        resultStr = DBWorker.TakeCabinet(SelectedCabinet,SelectedTeacher,SelectedGroup);
                        UpdateInfoView();
                        ShowMessageToUser(resultStr);
                        SetNullValuesToProperties();
                        wnd.Close();
                    }
                }
                );
            }
        }
        #endregion
    }
}
