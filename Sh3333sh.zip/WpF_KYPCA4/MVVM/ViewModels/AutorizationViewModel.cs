﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpF_KYPCA4.Commands;
using WpF_KYPCA4.MVVM.Models;
using WpF_KYPCA4.MVVM.Views;

namespace WpF_KYPCA4.MVVM.ViewModels
{
    public class AutorizationViewModel : Command
    {
        private void OpenMainWindow()
        {
            MainWindow mainWindow = new MainWindow();
            SetCenterPositionAndOpen(mainWindow);
        }
        #region CheckLoginPssword
        private RelayCommand checkAuthUser;
        public RelayCommand CheckAuthUser
        {
            get
            {
                return checkAuthUser ?? new RelayCommand(obj =>
                {
                    Window wnd = obj as Window;
                    string resultStr = "";
                    if (Login == null || Login.Replace(" ", "").Length == 0)
                    {
                        ShowMessageToUser("Некорректный логин");
                    }
                    if (Password == null || Password.Replace(" ", "").Length == 0)
                    {
                        ShowMessageToUser("Некорректный пароль");
                    }
                    else
                    {
                        resultStr = "Неправильный логин или пароль";
                        if (DBWorker.CheckAuthUser(Login, Password))
                        {
                            resultStr = "Успешный вход";
                            ShowMessageToUser(resultStr);
                            OpenMainWindow();
                            SetNullValuesToProperties();
                        }
                        else
                        {
                            ShowMessageToUser(resultStr);
                        }
                        SetNullValuesToProperties();
                    }
                }
                );
            }
        }
        #endregion
    }
}
