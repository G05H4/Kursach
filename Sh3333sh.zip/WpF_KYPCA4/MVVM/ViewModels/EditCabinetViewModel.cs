﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpF_KYPCA4.Commands;
using WpF_KYPCA4.MVVM.Models;

namespace WpF_KYPCA4.MVVM.ViewModels
{
    public class EditCabinetViewModel : Command
    {
        public RelayCommand EditCabinet
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    Window wnd = obj as Window;
                    string resultStr = "";
                    if (SelectedCabinet == null)
                    {
                        ShowMessageToUser("Не выбран кабинет");
                    }
                    else if (CabinetNumber == null)
                    {
                        ShowMessageToUser("Не выбран номер");
                    }
                    else if (CabinetName == null)
                    {
                        ShowMessageToUser("Не выбрано название");
                    }
                    else if (CabinetStatus == null)
                    {
                        ShowMessageToUser("Не выбран статус");
                    }
                    else
                    {
                        resultStr = DBWorker.EditCabinet(SelectedCabinet, CabinetNumber, CabinetName);
                        UpdateInfoView();
                        ShowMessageToUser(resultStr);
                        SetNullValuesToProperties();
                    }
                }
                );
            }
        }
    }
}
