﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpF_KYPCA4.Commands;
using WpF_KYPCA4.MVVM.Models;

namespace WpF_KYPCA4.MVVM.ViewModels
{
    public class AddGroupViewModel : Command
    {
        #region COMMANDS TO ADD
        public RelayCommand AddNewGroup
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    Window wnd = obj as Window;
                    string resultStr = "";
                    if (GroupName == null)
                    {
                        ShowMessageToUser("Не выбрана группа");
                    }
                    else
                    {
                        resultStr = DBWorker.CreateGroup(GroupName);
                        UpdateInfoView();
                        ShowMessageToUser(resultStr);
                        SetNullValuesToProperties();
                    }
                }
                );
            }
        }
        #endregion
    }
}
