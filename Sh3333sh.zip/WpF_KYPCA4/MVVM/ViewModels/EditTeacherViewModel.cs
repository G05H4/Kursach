﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpF_KYPCA4.Commands;
using WpF_KYPCA4.MVVM.Models;

namespace WpF_KYPCA4.MVVM.ViewModels
{
    public class EditTeacherViewModel : Command
    {
        public RelayCommand EditTeacher
        {
            get
            {
                return new RelayCommand(obj =>
                {
                    Window wnd = obj as Window;
                    string resultStr = "";
                    if (SelectedTeacher == null)
                    {
                        ShowMessageToUser("Не выбран учитель");
                    }
                    else if (TeacherFirstName == null)
                    {
                        ShowMessageToUser("Не выбрано имя");
                    }
                    else if (TeacherLastName == null)
                    {
                        ShowMessageToUser("Не выбрана фамилия");
                    }
                    else if (TeacherMiddleName == null)
                    {
                        ShowMessageToUser("Не выбрано отчество");
                    }
                    else
                    {
                        resultStr = DBWorker.EditTeacher(SelectedTeacher, TeacherFirstName, TeacherLastName, TeacherMiddleName);
                        UpdateInfoView();
                        ShowMessageToUser(resultStr);
                        SetNullValuesToProperties();
                    }
                }
                );
            }
        }
    }
}
